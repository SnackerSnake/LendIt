package lendit;

/**
 * Designed to more easily pass email addresses in to SQL as @ is not allowed
 * @author Joseph
 */
public class Email {
    private String local;
    private String domain;
    public Email(String e)
    {
        local = e.substring(0,e.indexOf("@"));
        domain = e.substring(e.indexOf("@")+1);
    }
    public Email(String l, String d)
    {
        local=l;
        domain=d;
    }
    public Email(Email e)
    {
        local=e.local;
        domain=e.domain;
    }
    public String getEmail()
    {
        return local + "@" + domain;
    }
    public String getDBStatement(DatabaseController.Operation o)
    {
        if(o==DatabaseController.Operation.Querey)
            return "EMAIL_LOCAL='" + local + "' AND EMAIL_DOMAIN='" + domain + "'";
        else if (o==DatabaseController.Operation.Insert)
            return "'" + local + "','" + domain + "'";
        return new String();
    }
    public static boolean isValid(String e)
    {
         if(!e.contains("@"))
             return false;
         return true;
    }
}
