/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lendit;

import java.util.Scanner;

/**
 * @author Joseph Nied
 */
public class LendIt {

    /**
     * @param args the command line arguments
     */
    static Scanner s;
    static Account account;
    public static DatabaseController dbc;
    public static void main(String[] args) {
       
            dbc = new DatabaseController();
        
            s = new Scanner(System.in);

            int menuOption = 0;
            while(menuOption!=3)
            {
                System.out.println("LogIn Menu:");
                System.out.println("1:Register");
                System.out.println("2:Log In");
                System.out.println("3:Quit");
                menuOption = s.nextInt();
                boolean loggedIn = false;
                switch(menuOption)
                {
                    case 1:
                        loggedIn = registerAccount();
                    break;
                    case 2:
                        loggedIn = logIn();
                    break;
                    case 3:
                    break;
                    default:
                        System.out.println("Try again");
                }
            }
    }
    public static boolean registerAccount()
    {
        System.out.println("Enter Email:");
        String email_string =s.next();
        if(!Email.isValid(email_string))
            return false;
        Email email = new Email(email_string);
        System.out.println("Enter Password:");
        String password = s.next();
        System.out.println("Confirm Password:");
        if(!password.equals(s.next()))
        {
            System.out.println("Passwords did not match. Returning to Menu");
            return false;
        }   
        System.out.println("Enter a Username:");
        String acc_name =  s.next();
        account = dbc.registerNewAccount(email, acc_name, password);
        if(account==null)
            return false;
        return true;
    }
    public static boolean logIn()
    {
        System.out.println("Enter Email:");
        String email_string =s.next();
        if(!Email.isValid(email_string))
            return false;
        Email email = new Email(email_string);
        System.out.println("Enter Password:");
        String password = s.next();
        account = dbc.logIn(email, password);
        if(account==null)
            return false;
        System.out.println("Logged In As: " + account.account_name);
        return true;
    }
}
