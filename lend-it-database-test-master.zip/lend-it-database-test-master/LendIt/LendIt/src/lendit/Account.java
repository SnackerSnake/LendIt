/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lendit;

/**
 *
 * @author Joseph
 */
public class Account {
    
    public String account_name;
    public Email email;
    public Account(String _account_name, Email _email)
    {
        account_name=_account_name;
        email = new Email(_email);
    }
    public String getDBStatement(DatabaseController.Operation o)
    {
        if(o==DatabaseController.Operation.Querey)
            return email.getDBStatement(o) + " AND ACC_NAME='" + account_name + "'";
        else if(o==DatabaseController.Operation.Insert)
            return email.getDBStatement(o) + ",'" + account_name + "'";
        return new String();
    }
}
