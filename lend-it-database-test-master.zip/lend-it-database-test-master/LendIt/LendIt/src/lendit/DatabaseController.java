/*
 * Joseph Nied
 * JWN5127@psu.edu
 * 11/8/2020
 * 
 * Database Controller for LendIt
 */
package lendit;

/**
 *
 * @author Joseph
 */
import java.sql.*;
public class DatabaseController {
    private Connection con;
    private Statement stmt;
    public enum Operation { Querey, Insert };
    public DatabaseController()
    {
        try{
            System.out.println("ESTABLISHING CONNECTION TO DATABASE");
            //con = DriverManager.getConnection("jdbc:derby://localhost:1527/LendIt","jwn5127","admin");
            con = DriverManager.getConnection("jdbc:mysql://lendit.fireelements.net:3306/lendit","lenditadmin","FsqaReukU8s62wE2rziH");
            System.out.println("CONNECTION ESTABLISHED");
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE); 
            
        }catch(SQLException e){
            System.err.println(e);
        }
    }
    public boolean existingAccount(Account a)
    {
        try{
            ResultSet rs = stmt.executeQuery("SELECT * FROM lendit.ACCOUNT WHERE " + a.getDBStatement(Operation.Querey));
            if(!rs.next())
                return false;
            return true;
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
    public boolean existingEmail(Email email)
    {
        try{
            ResultSet rs = stmt.executeQuery("SELECT * FROM lendit.ACCOUNT WHERE " + email.getDBStatement(Operation.Querey));
            if(!rs.next())
                return false;
            return true;
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
    public Account logIn(Email email,String pass)
    {
        if(existingEmail(email))
        {
            try{
                ResultSet rs = stmt.executeQuery("SELECT * FROM lendit.ACCOUNT WHERE " + email.getDBStatement(Operation.Querey) + " AND PASSWORD='" + pass + "'");
                
                if(!rs.next())
                    return null;
                String local = rs.getString("EMAIL_LOCAL");
                String domain = rs.getString("EMAIL_DOMAIN");
                String acc_name = rs.getString("ACC_NAME");
                return new Account(acc_name,new Email(local,domain));
            }catch(SQLException e){
                System.err.println(e);
                return null;
            }
        }
        System.err.println(email.getEmail() + " is not registered to an account.");
        return null;
    }
    public Account registerNewAccount(Email email, String acc_name, String pass)
    {
        if(existingEmail(email))
            return null;
        try{
            System.out.println("Attempting to register account");
            stmt.executeUpdate("INSERT INTO lendit.ACCOUNT (EMAIL_LOCAL,EMAIL_DOMAIN,ACC_NAME,PASSWORD) VALUES (" + email.getDBStatement(DatabaseController.Operation.Insert) + ",'" + acc_name + "','" + pass + "')");
            System.out.println("Successfully registered account");
            return logIn(email,pass);
        }catch(SQLException e){
            System.err.println(e);
            return null;
        }
    }
    public void close()
    {
        try{
            con.close();
            System.out.println("CONNECTION TERMINATED");
        }catch(SQLException e){
            System.err.println(e);
        }
    }
    public static void main(String[] args)
    {
        DatabaseController dbc = new DatabaseController();
        //dbc.close();
    }
}
