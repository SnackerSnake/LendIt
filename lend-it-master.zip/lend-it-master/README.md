# lend-it

Download and Install Git for Windows: https://git-scm.com/download/win

Open Android Studio -> Get Verision Control

Copy repo into URL: https://github.com/SWENG411/lend-it.git

To Make changes to code:
1. Create a branch from master in GitHub/Trello
2. <Do Work>
3. Open CMD and run: 
`git add .`
`git commit -m "Comment about your commit"`
`git push origin <branch>`

\\test Immekus