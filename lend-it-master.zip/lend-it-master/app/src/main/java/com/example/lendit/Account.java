package com.example.lendit;

import java.util.ArrayList;

/**
 * Stores information associated with an account
 * @author Joseph
 */
public class Account extends User {
    private ArrayList<User> friends;
    private ArrayList<Transaction> transactions;

    /**
     * Default constructor, no information stored
     */
    public Account() {
        super();
    }

    /**
     * Constructor that stores account id, username, password, and phone number
     * @param _account_id account id
     * @param _username username
     * @param _password password
     * @param _phone phone number
     */
    public Account(int _account_id, String _username, String _password, String _phone) {
        super(_account_id,_username,_password);
        phone = _phone;
    }

    /**
     * Gets all friends of the account
     * @return ArrayList of Users
     */
    public ArrayList<User> getFriends() {
        return friends;
    }

    /**
     * Sets the friends of the account
     * @param friends ArrayList of Users
     */
    public void setFriends(ArrayList<User> friends) {
        this.friends = friends;
    }

    /**
     * Gets all transactions associated with the account
     * @return ArrayList of Transactions
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * Sets the transactions associated with the account
     * @param transactions ArrayList of Transactions
     */
    public void setTransactions(ArrayList<Transaction> transactions) {
        this.transactions = transactions;
    }

}
