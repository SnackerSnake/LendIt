package com.example.lendit;


import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;


/**
 * Screen for viewing transactions
 */
public class TransactionScreen extends AppCompatActivity {

    private TextView friend;
    private TextView date;
    private EditText item;
    private EditText notes;
    private Button returned;
    private ImageView itemImage;

    /**
     * Actions to perform when screen is created
     */
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_screen);

        friend = findViewById(R.id.friendText);
        date = findViewById(R.id.dateTextView);
        item = findViewById(R.id.NameofItemBox);
        notes = findViewById(R.id.description);
        returned = findViewById(R.id.submit_button);
        itemImage = findViewById(R.id.ItemImage);

        Account session = DatabaseController.getDatabaseController().session;

        final int transaction = getIntent().getIntExtra("transaction", -1);
        final ArrayList<Transaction> arrayList = session.getTransactions();

        if (transaction != -1) {
            Transaction trans = new Transaction();

            for (Transaction i : arrayList) {
                if (i.getTransaction_id() == transaction) {
                    trans = i;
                    break;
                }
            }

            returned.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncReturnItem(transaction));
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(TransactionScreen.this, "Item has been returned!", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK, null);
                    finish();
                }
            });

            if (trans.getBorrowerID() == session.getAccount_id()) {
                DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUser(trans.getBorrowerID()));

                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                User friendUser = DatabaseController.getDatabaseController().user;
                if (friendUser != null ) { friend.setText(friendUser.getUsername()); }
            } else {
                DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUser(trans.getBorrowerID()));

                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                User friendUser = DatabaseController.getDatabaseController().user;
                if (friendUser != null ) { friend.setText(friendUser.getUsername()); }
            }

            final String imageUrl = "http://www.fireelements.net/uploads/" + trans.getImage_name() + ".jpeg";

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ImageHandler.getFromURL(imageUrl);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();

            itemImage.setImageBitmap(ImageHandler.getImage());
            date.setText(trans.getTo_return_on().toString());
            item.setText(trans.getItem_name());
            notes.setText(trans.getDescription());

            if (trans.isReturned()) {
                returned.setText("Item returned");
                returned.setClickable(false);
            }


        } else {
            Toast.makeText(TransactionScreen.this, "Error retrieving transaction.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
