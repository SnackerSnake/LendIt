package com.example.lendit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Screen to display chat
 */
public class ChatScreen extends AppCompatActivity {

    private EditText txtMobileNumb, txtMessage;
    Button buttonSend;
    SearchView searchView;
    ListView myList;


    /**
     * Actions to perform when screen is created
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_screen);

        txtMobileNumb = findViewById(R.id.ChatNumberAdd);
        txtMessage = findViewById(R.id.EnterMessage);

        buttonSend = findViewById(R.id.sendSMS);
        //Phone SMS request for permission
        ActivityCompat.requestPermissions(ChatScreen.this,new String[]{Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
        //Send button
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String msg = txtMessage.getText().toString();
                String mobileNumb = txtMobileNumb.getText().toString();
                //test for correct input of number and message
                if(mobileNumb != null)
                {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(mobileNumb, null, msg, null, null);

                    Toast.makeText(ChatScreen.this, "Message Sent", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(ChatScreen.this, "Message Failed", Toast.LENGTH_LONG).show();
                }

            }
        });

    //Getting friends list for chat page and allowing for search
        final ArrayList<User> arrayList = DatabaseController.getDatabaseController().session.getFriends();



        searchView = findViewById(R.id.searchView);
        myList = findViewById(R.id.myList);

        final ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        myList.setAdapter(arrayAdapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) { return false; }

            @Override
            public boolean onQueryTextChange(String s) {
                arrayAdapter.getFilter().filter(s);
                return false;
            }
        });

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String phone = arrayList.get(position).phone;
                if(phone==null || phone.equals(""))
                    Toast.makeText(ChatScreen.this, arrayList.get(position).getUsername() + " does not have a phone number.", Toast.LENGTH_SHORT).show();
                else
                {
                    Toast.makeText(ChatScreen.this, "Filled " + arrayList.get(position).getUsername() + "'s phone number.", Toast.LENGTH_SHORT).show();
                    txtMobileNumb.setText(phone);
                }
            }
        });


    }
}