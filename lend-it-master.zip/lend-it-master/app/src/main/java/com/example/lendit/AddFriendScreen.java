package com.example.lendit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Screen for adding friends
 */
public class AddFriendScreen extends AppCompatActivity {

    private Button findButton;
    private EditText editTextFriendName;
    private EditText editTextPhone;

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend_screen);

        findButton = findViewById(R.id.findButton);
        editTextFriendName = findViewById(R.id.editTextFriendName);
        editTextPhone = findViewById(R.id.editTextPhone);

        editTextFriendName.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(20)});
        editTextPhone.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(10)});



        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String friend_username = editTextFriendName.getText().toString();
                String friend_phone = editTextPhone.getText().toString();

                DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetFriends());

                ArrayList<User> friends = DatabaseController.getDatabaseController().session.getFriends();
                boolean user_found = false;
                for (User u : friends) {
                    if (friend_username.equals(u.username)||friend_phone.equals(u.phone)) {
                        friend_username=u.username;
                        user_found = true;
                        break;
                    }
                }
                if (user_found)
                    Toast.makeText(AddFriendScreen.this, friend_username + " is already on your friends list!", Toast.LENGTH_SHORT).show();
                else {
                    DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUserList());
                    ArrayList<User> users = DatabaseController.getDatabaseController().users;
                    user_found = false;
                    for (User u : users) {
                        if (friend_username.equals(u.username)||(friend_phone.equals(u.phone)&&!friend_phone.isEmpty())) {
                            user_found = true;
                            friend_username = u.username;
                            DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncAddFriend(u.account_id));
                            DatabaseController.getDatabaseController().session.getFriends().add(u);
                            DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetFriends());
                            break;
                        }
                    }
                    if (user_found) {
                        Toast.makeText(AddFriendScreen.this, "Added " + friend_username + " to friends list!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else
                        Toast.makeText(AddFriendScreen.this, "Could not find user: " + friend_username, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}