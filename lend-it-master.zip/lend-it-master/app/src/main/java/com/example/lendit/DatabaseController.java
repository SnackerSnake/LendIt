/*
 * Joseph Nied
 * JWN5127@psu.edu
 * 12/2/2020
 * 
 * Database Controller for LendIt
 */
package com.example.lendit;

import java.sql.*;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Database controller, performs multiple functions to save and get information from the DB
 */
public class DatabaseController {
    private static DatabaseController dbcObject = null; //singleton
    private Statement stmt;
    public Connection con;
    public Account session;
    public ArrayList<User> users;
    public User user;
    ExecutorService executor; //used to execute async operations

    /**
     * Default constructor
     */
    private DatabaseController() {
        session=new Account();
        users = new ArrayList<User>();
        executor = Executors.newFixedThreadPool(10);
    }

    /**
     * Establishes a connection to the MySQL database
     */
    public void connect()
    {
        try{
            if(con!=null)
                con.close();
            con = DriverManager.getConnection("jdbc:mysql://lendit.fireelements.net:3306/lendit","lenditadmin","FsqaReukU8s62wE2rziH");
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
        }catch(SQLException e) {
            System.err.println(e);
        }
    }

    /**
     * Get single instance
     * @return singleton instance
     */
    public static DatabaseController getDatabaseController() //get singleton instance
    {
        if(dbcObject == null)
            dbcObject= new DatabaseController();
        return dbcObject;
    }

    /**
     * Checks DB for account and logs them in
     * @param username username
     * @param password password
     * @return account id if successful
     */
    public boolean logIn(String username, String password) {//returns account with account id = -1 if not found otherwise all account information
        connect();
        session = new Account();
        try{
            ResultSet rs = stmt.executeQuery("SELECT * FROM lendit.USERACCOUNTS WHERE USERNAME='" + username + "' AND PASSWORD='" + password + "'");
            if(rs.next())
                session = new Account(
                rs.getInt("ACCOUNT_ID"),
                rs.getString("USERNAME"),
                rs.getString("PASSWORD"),
                rs.getString("PHONE")
               );
            else
                session.account_id = -1;
        }catch(SQLException e){
            System.err.println(e);
        }
        return session.account_id != -1;
    }

    /**
     * Sets account_id to -2 so it's known a user is not logged in
     */
    public void resetLogin() {
        if (session.account_id != -2) {
            session.account_id = -2;
        }
    }

    /**
     * Gets transactions and friends after a user logs in
     */
    public void loggedIn() {
        connect();
        getTransactions();
        getFriends();
    }

    /**
     * Gets a list of all user accounts in the DB
     */
    public void getUserList()
    {
        connect();
        ArrayList<User> useraccounts = new ArrayList<User>();
        try{
            ResultSet rs = stmt.executeQuery("SELECT * "
                    + "FROM lendit.USERACCOUNTS");
            while(rs.next())
                useraccounts.add(new User(rs.getInt("ACCOUNT_ID"),rs.getString("USERNAME"),rs.getString("PHONE")));
        }catch(SQLException e){
            System.err.println(e);
        }
        users = useraccounts;
    }

    /**
     * Adds a registered account to the DB
     * @param username username
     * @param password password
     * @param phone phone number
     * @return log in
     */
    public boolean registerAccount(String username, String password,String phone) { //if account_id=-1 then error registering otherwise adds account to database
        connect();
        try{
            stmt.executeUpdate("INSERT INTO lendit.USERACCOUNTS (USERNAME,PASSWORD,PHONE) "
                    + "VALUES ('" + username + "','" + password + "','" + phone + "')");
            return logIn(username,password);
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }

    /**
     * Gets all friends of a user
     */
    public void getFriends() { //returns arraylist of account_ids of specified account's friends
        connect();
        ArrayList<User> friends = new ArrayList<User>();
        try{
            ResultSet rs = stmt.executeQuery("SELECT FRIEND_ID,USERNAME,PHONE "
                    + "FROM (lendit.FRIENDS LEFT OUTER JOIN lendit.USERACCOUNTS ON lendit.FRIENDS.FRIEND_ID=lendit.USERACCOUNTS.ACCOUNT_ID) "
                    + "WHERE lendit.FRIENDS.ACCOUNT_ID='" + session.account_id + "'");
            while(rs.next())
                friends.add(new User(rs.getInt("FRIEND_ID"),rs.getString("USERNAME"),rs.getString("PHONE")));
        }catch(SQLException e){
            System.err.println(e);
        }
        session.setFriends(friends);
    }

    /**
     * Adds a friend for a user
     * @param friend friend account_id
     */
    public void addFriend(int friend){
        connect();
        try{
            stmt.executeUpdate("INSERT INTO lendit.FRIENDS (ACCOUNT_ID,FRIEND_ID) "
                    + "VALUES ('" + session.account_id + "','" + friend + "')");
        }catch(SQLException e){
            System.err.println(e);
        }
    }

    /**
     * Changes a user's username
     * @param username username string
     */
    public void changeUsername(String username)
    {
        connect();
        try{
            stmt.executeUpdate("UPDATE lendit.USERACCOUNTS "
                    + "SET USERNAME='" + username + "'"
                    + "WHERE lendit.USERACCOUNTS.ACCOUNT_ID='" + session.account_id + "'");
            session.username = username;
        }catch(SQLException e){
            System.err.println(e);
        }
    }

    /**
     * Changes a user's phone number
     * @param phone phone number string
     */
    public void changePhone(String phone){
        connect();
        try{
            stmt.executeUpdate("UPDATE lendit.USERACCOUNTS "
                    + "SET PHONE='" + phone + "'"
                    + "WHERE lendit.USERACCOUNTS.ACCOUNT_ID='" + session.account_id + "'");
            session.phone = phone;
        }catch(SQLException e){
            System.err.println(e);
        }
    }

    /**
     * Gets a user account
     * @param account_id account_id of user to get
     * @return User object
     */
    public User getUser(int account_id)
    {
        connect();
        User u = new User();
        try{
            ResultSet rs = stmt.executeQuery("SELECT ACCOUNT_ID,USERNAME "
                    + "FROM lendit.USERACCOUNTS "
                    + "WHERE ACCOUNT_ID='" + account_id + "'");
            if(rs.next())
                u = new User(rs.getInt("ACCOUNT_ID"),rs.getString("USERNAME"));
                user = u;
        }catch(SQLException e){
            System.err.println(e);
        }
        return u;
    }

    /**
     * Gets all transactions for a user
     */
    public void getTransactions() {
        connect();
        ArrayList<Transaction> transaction_log = new ArrayList();
        try{
            ResultSet rs = stmt.executeQuery("SELECT * "
                + "FROM lendit.TRANSACTIONLOG AS T, "
                + "lendit.USERACCOUNTS AS L, "
                + "lendit.USERACCOUNTS AS B "
                + "WHERE (T.LENDER_ID=L.ACCOUNT_ID AND "
                + "T.BORROWER_ID=B.ACCOUNT_ID) AND "
                + "(T.LENDER_ID='" + session.account_id + "' OR T.BORROWER_ID='" + session.account_id +"') ORDER BY TRANSACTION_ID");
            while(rs.next())
                transaction_log.add(new Transaction(
                    rs.getInt("T.TRANSACTION_ID"),
                    new User(rs.getInt("T.LENDER_ID"),rs.getString("L.USERNAME")),
                    new User(rs.getInt("T.BORROWER_ID"),rs.getString("B.USERNAME")),
                    new Item(rs.getString("T.ITEM_NAME")),
                    rs.getDate("BORROWED_ON"),
                    rs.getDate("TO_RETURN_ON"),
                    rs.getBoolean("RETURNED"),
                    rs.getString("DESCRIPTION"),
                    rs.getString("IMAGE")
                ));
        }catch(SQLException e){
            System.err.println(e);
        }
        session.setTransactions(transaction_log);
    }

    /**
     * Adds a transaction
     * @param t Transaction to add
     */
    public void addTransaction(Transaction t){
        connect();
        try{
            stmt.executeUpdate("INSERT INTO lendit.TRANSACTIONLOG (LENDER_ID,BORROWER_ID,ITEM_NAME,BORROWED_ON,TO_RETURN_ON,RETURNED,DESCRIPTION,IMAGE) "
                    + "VALUES ('" + t.getLenderID()
                    + "','" + t.getBorrowerID()
                    + "','" + t.getItem_name()
                    + "','" + t.getBorrowed_on()
                    + "','" + t.getTo_return_on()
                    + "','" + (t.isReturned()?1:0)
                    + "','" + t.getDescription()
                    + "','" + t.getImage_name() +"')");
        }catch(SQLException e){
            System.err.println(e);
        }
        getTransactions();
    }

    /**
     * Sets an item as returned
     * @param id id of transaction to mark returned
     */
    public void returnItem(int id) {
        connect();
        try{
            int rs = stmt.executeUpdate("UPDATE lendit.TRANSACTIONLOG "
                    + "SET RETURNED='1'"
                    + "WHERE lendit.TRANSACTIONLOG.TRANSACTION_ID='" + id + "'");
        }catch(SQLException e){
            System.err.println(e);
        }
        getTransactions();
    }

    /**
     * Checks if a username has already been registered
     * @param username username string
     * @return false if username is available
     */
    public boolean usernameTaken(String username) {
        for(User u : users)
            if(username.equals(u.getUsername()))
                return true;
        return false;
    }

    /**
     * Checks if a phone number has already been registered
     * @param phone phone number string
     * @return false if username is available
     */
    public boolean phoneNumberTaken(String phone) {
        for(User u : users) {
            if (phone.equals(u.getPhone())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Executes the DB command
     * @param a command to run
     * @return null
     */
    public User execute(Runnable a) {
        executor.submit(a);
        return null;
    }

    /**
     * Async method to perform log in
     */
    public static class AsyncLogIn implements Runnable {
        private String username;
        private String password;
        public AsyncLogIn(String _username, String _password) {
            username=_username;
            password=_password;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().logIn(username,password); }
    }

    /**
     * Async method to perform logged in
     */
    public static class AsyncLoggedIn implements Runnable {
        @Override
        public void run() { DatabaseController.getDatabaseController().loggedIn(); }
    }

    /**
     * Async method to perform account registration
     */
    public static class AsyncRegisterAccount implements Runnable {
        private String username;
        private String password;
        private String phone;
        public AsyncRegisterAccount(String _username, String _password, String _phone) {
            username=_username;
            password=_password;
            phone=_phone;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().registerAccount(username,password,phone); }
    }

    /**
     * Async method to perform get friends
     */
    public static class AsyncGetFriends implements Runnable {
        @Override
        public void run() {
            DatabaseController.getDatabaseController().getFriends();
        }
    }

    /**
     * Async method to perform get users
     */
    public static class AsyncGetUserList implements Runnable {
        @Override
        public void run() { DatabaseController.getDatabaseController().getUserList(); }
    }

    /**
     * Async method to perform get user
     */
    public static class AsyncGetUser implements Runnable {
        int id;
        public AsyncGetUser(int i) { id = i; }
        @Override
        public void run() { DatabaseController.getDatabaseController().getUser(id);}
    }

    /**
     * Async method to perform add friend
     */
    public static class AsyncAddFriend implements Runnable {
        private int friend;
        public AsyncAddFriend(int _friend) {
            friend=_friend;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().addFriend(friend); }
    }

    /**
     * Async method to perform add transaction
     */
    public static class AsyncAddTransaction implements Runnable {
        private Transaction t;
        public AsyncAddTransaction(Transaction _t) {
            t = _t;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().addTransaction(t); }
    }

    /**
     * Async method to perform return item
     */
    public static class AsyncReturnItem implements Runnable {
        private int id;
        public AsyncReturnItem(int _id) {id = _id; }
        @Override
        public void run() { DatabaseController.getDatabaseController().returnItem(id); }
    }

    /**
     * Async method to perform change user name
     */
    public static class AsyncChangeUsername implements Runnable {
        private String username;
        public AsyncChangeUsername(String _username) {
            username = _username;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().changeUsername(username); }
    }

    /**
     * Async method to perform change phone number
     */
    public static class AsyncChangePhone implements Runnable {
        private String phone;
        public AsyncChangePhone(String _phone) {
            phone = _phone;
        }
        @Override
        public void run() { DatabaseController.getDatabaseController().changePhone(phone); }
    }
}
