package com.example.lendit;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

/**
 * Class with methods to handle uploading and downloading images from an external server
 */
public class ImageHandler extends Activity {
    private static final String serverUrl = "http://www.fireelements.net/upload.php";
    private static Bitmap image;


    /**
     * Updates a bitmap image from Android to an external web server
     * @param image bitmap image
     * @param imageName name of file to save
     * @param cache location of app's cache directory
     * @return response code from server
     * @throws IOException Exceptions
     */
    public static int uploadFile(Bitmap image, String imageName, File cache) throws IOException {
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int maxBufferSize = 1 * 1024 * 1024;

        File imageFile = bitmapConversion(cache, image, imageName);

        FileInputStream fileInputStream = new FileInputStream(imageFile);
        URL url = new URL(serverUrl);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Connection", "Keep-Alive");
        conn.setRequestProperty("ENCTYPE", "multipart/form-data");
        conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
        conn.setRequestProperty("uploaded_file", imageName);

        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
        dos.writeBytes(twoHyphens + boundary + lineEnd);
        dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + imageName + "\"" + lineEnd);
        dos.writeBytes(lineEnd);

        int bytesAvailable = fileInputStream.available();
        int bufferSize = Math.min(bytesAvailable, maxBufferSize);
        byte[] buffer = new byte[bufferSize];
        int bytesRead = fileInputStream.read(buffer, 0, bufferSize);

        while (bytesRead > 0) {
            dos.write(buffer, 0, bufferSize);
            bytesAvailable = fileInputStream.available();
            bufferSize = Math.min(bytesAvailable, maxBufferSize);
            bytesRead = fileInputStream.read(buffer, 0, bufferSize);
        }

        dos.writeBytes(lineEnd);
        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

        fileInputStream.close();
        dos.flush();
        dos.close();

        return conn.getResponseCode();
    }

    /**
     * Converts a bitmap from Android to a jpeg for upload
     * @param cache Location of app's cache directory
     * @param image bitmap image to upload
     * @param fileName name of file to create
     * @return jpeg file
     * @throws IOException Exceptions
     */
    public static File bitmapConversion(File cache, Bitmap image, String fileName) throws IOException {
        File imageFile = new File(cache, fileName);
        imageFile.createNewFile();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, bos);
        byte[] bitmapdata = bos.toByteArray();

        FileOutputStream fos = new FileOutputStream(imageFile);
        fos.write(bitmapdata);
        fos.flush();
        fos.close();

        return imageFile;
    }

    /**
     * Generates a random name for an image
     * @param len length of name to generate
     * @return random string
     */
    public static String imageName(int len) {
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(len);
        String randChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        for (int i = 0; i < len; i ++)
            sb.append(randChars.charAt(rnd.nextInt(randChars.length())));

        return sb.toString();
    }

    /**
     * Gets an image from a URL and saves it as a bitmap
     * @param src URL to retreive image from
     * @throws IOException Exceptions
     */
    public static void getFromURL(String src) throws IOException {
        URL url = new URL(src);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setDoOutput(true);
        con.connect();

        InputStream ins = con.getInputStream();
        image = BitmapFactory.decodeStream(ins);
    }

    /**
     * Gets a bitmap image pulled from an URL
     * @return bitmap image
     */
    public static Bitmap getImage() {
        return image;
    }
}
