package com.example.lendit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

/**
 * First screen of the app
 */
public class MainActivity extends AppCompatActivity {

    private EditText name;
    private EditText password;
    private Button login, register;
    private RelativeLayout loadBar;


    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_main);

        name = findViewById(R.id.NameText);
        password = findViewById(R.id.PasswordText);
        login = findViewById(R.id.LoginButton);
        register = findViewById(R.id.RegisterButton);
        loadBar = findViewById(R.id.loadingPanel);
        loadBar.setVisibility(View.GONE);

        name.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(20)});

        //login button
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseController.getDatabaseController().resetLogin();
                String inputName = name.getText().toString();
                String inputPassword = password.getText().toString();

                if (!inputName.isEmpty() && !inputPassword.isEmpty()) {
                    if (inputName.trim().length() < inputName.length() || inputPassword.trim().length() < inputPassword.length()) {
                        Toast.makeText(MainActivity.this, "Please remove spaces", Toast.LENGTH_SHORT).show();
                    } else {
                        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncLogIn(inputName, inputPassword));
                        while (DatabaseController.getDatabaseController().session.account_id == -2) { }

                        if (DatabaseController.getDatabaseController().session.account_id != -1) {
                            DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncLoggedIn());
                            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show(); // shows bubble that successful
                            Intent intent = new Intent(MainActivity.this, HomeScreen.class);  // connects successful login with opening HomeScreen
                            startActivity(intent);
                        } else
                            Toast.makeText(MainActivity.this, "Invalid Login", Toast.LENGTH_SHORT).show(); //comments if invalid username or pass
                    }
                } else
                    Toast.makeText(MainActivity.this, "Please Enter Info", Toast.LENGTH_SHORT).show(); // asks for info if one or both missing
            }
        });

        //registration button
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent_register = new Intent(MainActivity.this, RegisterScreen.class);
                startActivity(intent_register);
            }
        });
    }
}