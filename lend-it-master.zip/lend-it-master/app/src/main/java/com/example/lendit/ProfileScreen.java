package com.example.lendit;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Screen for the user profile
 */
public class ProfileScreen extends AppCompatActivity {

    private static final int CAMERA_PERM_CODE = 101;
    public static final int Gallery_Request = 103;
    private ImageView selectedImage;
    private Button galImage;
    private ListView listView;
    private Button save;
    private EditText phone;
    private EditText name;

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_screen);

        galImage = findViewById(R.id.ProfilePictureButton);
        selectedImage = findViewById(R.id.imageView);
        listView = findViewById(R.id.listView);
        save = findViewById(R.id.saveButton);
        phone = findViewById(R.id.editTextPhone);
        name = findViewById(R.id.editTextTextPersonName);

        galImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askGalleryPermissions();
            }
        });

        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUserList());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = name.getText().toString();
                String phoneNumber = phone.getText().toString();

                Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
                Matcher m = p.matcher(phoneNumber);
                boolean b = m.find();

                if (!username.equals(DatabaseController.getDatabaseController().session.getUsername())) {
                    if (username.isEmpty()) {
                        Toast.makeText(ProfileScreen.this, "Please enter a username.", Toast.LENGTH_SHORT).show();
                    } else if (username.trim().length() < username.length()) {
                        Toast.makeText(ProfileScreen.this, "Please remove spaces from username.", Toast.LENGTH_SHORT).show();
                    } else if(DatabaseController.getDatabaseController().usernameTaken(username)){
                        Toast.makeText(ProfileScreen.this, "Username " + username + " already taken.", Toast.LENGTH_SHORT).show();
                    } else {
                        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncChangeUsername(username));
                        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUserList());
                        DatabaseController.getDatabaseController().session.username=username;
                        Toast.makeText(ProfileScreen.this, "Username successfully changed to: " + username, Toast.LENGTH_SHORT).show();
                    }
                }
                if (!phoneNumber.equals(DatabaseController.getDatabaseController().session.getPhone())) {
                    if (phoneNumber.isEmpty()) {
                        Toast.makeText(ProfileScreen.this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
                    } else if (phoneNumber.trim().length() < phoneNumber.length()) {
                        Toast.makeText(ProfileScreen.this, "Please remove spaces from phone number.", Toast.LENGTH_SHORT).show();
                    } else if (b) {
                        Toast.makeText(ProfileScreen.this, "Please remove special chars from phone number.", Toast.LENGTH_SHORT).show();
                    } else if (DatabaseController.getDatabaseController().phoneNumberTaken(phoneNumber)){
                        Toast.makeText(ProfileScreen.this, "Phone number " + phoneNumber + " already registered to another account.", Toast.LENGTH_SHORT).show();
                    } else {
                        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncChangePhone(phoneNumber));
                        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetUserList());
                        DatabaseController.getDatabaseController().session.phone=phoneNumber;
                        Toast.makeText(ProfileScreen.this, "Phone number successfully changed to: " + phoneNumber, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //Display the transaction list
        if (DatabaseController.getDatabaseController().session.getTransactions() != null) {
            final ArrayList<Transaction> arrayList = DatabaseController.getDatabaseController().session.getTransactions();
            ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.list_layout, arrayList);
            listView.setAdapter(arrayAdapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent_lend = new Intent(ProfileScreen.this, TransactionScreen.class);
                    intent_lend.putExtra("transaction", arrayList.get(position).getTransaction_id());
                    startActivityForResult(intent_lend, 1);
                }
            });
        }

        ((TextView)(findViewById(R.id.editTextTextPersonName))).setText(DatabaseController.getDatabaseController().session.username);
        ((TextView)(findViewById(R.id.editTextPhone))).setText(DatabaseController.getDatabaseController().session.phone);
    }

    /**
     * Requests permission to use the camera
     */
    private void askGalleryPermissions() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        } else {
            openGallery();
        }
    }

    /**
     * Opens the Android gallery
     */
    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, Gallery_Request);
    }

    /**
     * Process to run when activity result is returned
     * @param requestCode Request code for activity request
     * @param resultCode Result code for activity
     * @param data Data of intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (Activity.RESULT_OK == resultCode && requestCode == Gallery_Request) {
            Uri getIm = data.getData();
            try {
                ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), getIm);
                Bitmap image = ImageDecoder.decodeBitmap(source);
                // This was deprecated in API 29:
                // Bitmap image = MediaStore.Images.Media.getBitmap(this.getContentResolver(),getIm);
                selectedImage.setImageBitmap(image);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {
            return;
        } else if (resultCode == RESULT_OK) {
            Intent refresh = new Intent(this, ProfileScreen.class);
            startActivity(refresh);
            this.finish();
        }
        super.onActivityResult(requestCode,resultCode,null);
    }
}