package com.example.lendit;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * Screen to display the Friends List
 */
public class FriendList extends AppCompatActivity {

    ListView listView;

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_list);
        listView = findViewById(R.id.listView);

        DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncGetFriends());
        final ArrayList<User> arrayList = DatabaseController.getDatabaseController().session.getFriends();

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("id", arrayList.get(position).getAccount_id());
                resultIntent.putExtra("username", arrayList.get(position).getUsername());
                setResult(Activity.RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}