package com.example.lendit;

import java.sql.Date;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

/**
 * Screen for borrowing items
 */
public class BorrowScreen extends AppCompatActivity {
    //surprise tools to help us later
    public static final int CAMERA_PERM_CODE = 101;
    public static final int Camera_Request = 102;
    public static final int Gallery_Request = 103;
    public static final int Friend_Request = 104;
    private boolean isDate;
    private boolean isFriend;
    private boolean isNameOfItem;
    private boolean isDescription;
    private Button lendImage;
    private Button submit_button;
    private Button galImage;
    private ImageButton friendButton;
    private ImageView selectedImage;
    private EditText nameOfItem;
    private EditText description;
    private TextView dateSet;
    private TextView friendText;
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private Transaction trans = new Transaction();

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow_screen);

        isDate = false;
        isFriend = false;
        isNameOfItem = false;
        isDescription = false;

        selectedImage = findViewById(R.id.ItemImage);
        lendImage = findViewById(R.id.ItemButton);
        galImage = findViewById(R.id.itemButton2);
        friendButton = findViewById(R.id.SelectFriendButton);
        dateSet = findViewById(R.id.dateTextView);
        submit_button = findViewById(R.id.submit_button);
        nameOfItem = findViewById(R.id.NameofItemBox);
        description = findViewById(R.id.description);
        friendText = findViewById(R.id.friendText);

        lendImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askCameraPermissions();
            }
        });

        galImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askGalleryPermissions();
            }
        });

        //No emoji support
        nameOfItem.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(20)});
        description.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(100)});

        friendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_friends = new Intent(BorrowScreen.this, FriendList.class);
                startActivityForResult(intent_friends, Friend_Request);
            }
        });

        dateSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                String date = year + "-" + month + "-" + day;
                trans.setBorrowed_on(Date.valueOf(date));
                isDate = true;

                DatePickerDialog dialog = new DatePickerDialog(BorrowScreen.this, dateSetListener, year, month, day);
                dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                dialog.show();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month++;
                String date = year + "-" + month + "-" + dayOfMonth;
                dateSet.setText(date);
                trans.setTo_return_on(Date.valueOf(date));
            }
        };

        //when user presses the submit button, it adds the content to the database and sends the user back to home page
        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isNameOfItem = false;
                isDescription = false;
                String nameOfItem_string = nameOfItem.getText().toString();
                String description_string = description.getText().toString();

                if (!nameOfItem_string.isEmpty()) {
                    isNameOfItem = true;
                }

                if (!description_string.isEmpty()) {
                    isDescription = true;
                }

                if (isDate && isFriend && isNameOfItem && isDescription) {
                    trans.setBorrower(DatabaseController.getDatabaseController().session);
                    trans.setReturned(false);
                    trans.setItem_name(nameOfItem_string);
                    trans.setDescription(description_string);
                    final String imageName = ImageHandler.imageName(20);
                    trans.setImage_name(imageName);

                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ImageHandler.uploadFile(trans.getImage(), imageName + ".jpeg", getCacheDir());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    t.start();
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncAddTransaction(trans));

                    Toast.makeText(BorrowScreen.this, "Item has been borrowed!", Toast.LENGTH_SHORT).show();

                    finish();

                } else {
                    Toast.makeText(BorrowScreen.this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Gets Android camera permissions when using the camera
     */
    private void askCameraPermissions() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        }else{
            openCamera();
        }
    }

    /**
     * Gets Android camera permissions when using the gallery
     */
    private void askGalleryPermissions() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        } else {
            openGallery();
        }
    }

    /**
     * Actions to perform when permission request results are returned
     * @param requestCode Request code for permission request
     * @param permissions What permissions are requested
     * @param grantResults Results of permission request
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == CAMERA_PERM_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //open Camera();
            }else{
                Toast.makeText(this, "Camera Permission is needed", Toast.LENGTH_SHORT).show();
            }
        }
    }


    /**
     * Opens the Android camera
     */
    private void openCamera() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, Camera_Request);
    }

    /**
     * Opens the Android gallery
     */
    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, Gallery_Request);
    }

    /**
     * Process to run when activity result is returned
     * @param requestCode Request code for activity request
     * @param resultCode Result code for activity
     * @param data Data of intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (Activity.RESULT_OK == resultCode && requestCode == Camera_Request) {
            Bitmap image = (Bitmap) data.getExtras().get("data");
            trans.setImage(image);
            selectedImage.setImageBitmap(image);
        } else if (Activity.RESULT_OK == resultCode && requestCode == Gallery_Request) {
            Uri getIm = data.getData();
            try {
                ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), getIm);
                Bitmap image = ImageDecoder.decodeBitmap(source);
                // This was deprecated in API 29:
                // Bitmap image = MediaStore.Images.Media.getBitmap(this.getContentResolver(),getIm);
                trans.setImage(image);
                selectedImage.setImageBitmap(image);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (resultCode == Activity.RESULT_OK && requestCode == Friend_Request) {
            int result_id = data.getIntExtra("id", 1);
            String result_username = data.getStringExtra("username");
            trans.setLender(new User(result_id));
            friendText.setText(result_username);
            isFriend = true;
        } else if (resultCode == Activity.RESULT_CANCELED) {
            return;
        }
        super.onActivityResult(requestCode,resultCode,null);
    }
}