package com.example.lendit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * The Home Screen of the app
 */
public class HomeScreen extends AppCompatActivity {

    private Button lend;
    private Button borrow;
    private Button chat;
    private Button profile;
    private Button addFriend;

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        lend = findViewById(R.id.LendButton);
        borrow = findViewById(R.id.BorrowButton);
        chat = findViewById(R.id.ChatButton);
        profile = findViewById(R.id.ProfileButton);
        addFriend = findViewById(R.id.AddFriend);

        // All button activations
        lend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_lend = new Intent(HomeScreen.this, LendScreen.class);
                startActivity(intent_lend);
            }
        });

        borrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_borrow = new Intent(HomeScreen.this, BorrowScreen.class);
                startActivity(intent_borrow);
            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_chat = new Intent(HomeScreen.this, ChatScreen.class);
                startActivity(intent_chat);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_chat = new Intent(HomeScreen.this, ProfileScreen.class);
                startActivity(intent_chat);
            }
        });

        addFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_chat = new Intent(HomeScreen.this, AddFriendScreen.class);
                startActivity(intent_chat);
            }
        });
    }
}