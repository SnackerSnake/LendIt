package com.example.lendit;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Screen for Account Registration
 */
public class RegisterScreen extends AppCompatActivity {

    private EditText username;
    private EditText password_one;
    private EditText password_two;
    private EditText phone_number;
    private Button register;

    /**
     * Actions to perform when screen is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);

        //takes in the inputs of the user with text fields and button
        username = findViewById(R.id.input_username);
        password_one = findViewById(R.id.input_password);
        password_two = findViewById(R.id.input_password_second);
        phone_number = findViewById(R.id.input_phone_number);
        register = findViewById(R.id.register_button);

        username.setFilters(new InputFilter[]{new TextFilter.Emoji(), new TextFilter.Length(20)});

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //turns user inputs into strings
                String input_username = username.getText().toString();
                String input_password = password_one.getText().toString();
                String input_password_two = password_two.getText().toString();
                String input_phone_number = phone_number.getText().toString();

                Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
                Matcher m = p.matcher(input_phone_number);
                boolean b = m.find();



                //will not let the user register if the email text field is empty
                if (input_username.isEmpty()) {
                    Toast.makeText(RegisterScreen.this, "Please enter your username.", Toast.LENGTH_SHORT).show();
                    //will not let the user register if one of the password text fields is empty
                } else if (input_password.isEmpty() || input_password_two.isEmpty()) {
                    Toast.makeText(RegisterScreen.this, "Please enter a password in both fields.", Toast.LENGTH_SHORT).show();
                } else if (!input_password.equals(input_password_two)) {
                    Toast.makeText(RegisterScreen.this, "Passwords Do Not Match.", Toast.LENGTH_SHORT).show();
                } else if(input_phone_number.isEmpty()) {
                    Toast.makeText(RegisterScreen.this, "Please enter your phone number", Toast.LENGTH_SHORT).show();
                } else if (input_username.trim().length() < input_username.length()
                || input_password.trim().length() < input_password.length()
                || input_password_two.trim().length() < input_password_two.length()
                || input_phone_number.trim().length() < input_phone_number.length()) {
                    Toast.makeText(RegisterScreen.this, "Please remove all spaces", Toast.LENGTH_SHORT).show();
                } else if (b) {
                    Toast.makeText(RegisterScreen.this, "Please remove special chars for phone number", Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseController.getDatabaseController().execute(new DatabaseController.AsyncRegisterAccount(input_username, input_password, input_phone_number));

                    Toast.makeText(RegisterScreen.this, "Account Created", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(RegisterScreen.this, MainActivity.class);

                    startActivity(intent);
                    //}
                }
            }
        });
    }
}