package com.example.lendit;

import android.text.InputFilter;
import android.text.Spanned;

/**
 * Class to handling text filters
 */
public class TextFilter {
    /**
     * Blocks emoji from being entered in to a field
     */
    public static class Emoji implements InputFilter {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL || end > 20) {
                    return "";
                }
            }
            return null;
        }
        public static InputFilter lengthFilter = new InputFilter.LengthFilter(20);
    }

    /**
     * Sets the maximum length of a text field
     */
    public static class Length extends InputFilter.LengthFilter {
        public Length(int max) {
            super(max);
        }
    }
}
