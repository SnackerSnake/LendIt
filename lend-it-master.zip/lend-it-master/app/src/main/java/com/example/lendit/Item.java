package com.example.lendit;

import android.graphics.Bitmap;

/**
 * Stores item that is lent or borrowed
 * @author Joseph Nied
 */
public class Item {
    public String item_name;
    public Bitmap image;

    /**
     * Default constructor, blank item name
     */
    public Item(){
        item_name="";
    }

    /**
     * Constructor that populates the item's name
     * @param _item_name name of item
     */
    public Item(String _item_name){
        item_name = _item_name;
    }
    /**
     * Get the name of the item
     * @return item name
     */
    @Override
    public String toString()
    {
        return item_name;
    }
}
