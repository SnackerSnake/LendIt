package com.example.lendit;

/**
 * Stores account users and their attributes
 * @author Joseph
 */
public class User {
    protected int account_id;
    protected String username;
    protected String phone;

    /**
     * Gets the user's phone number
     * @return phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Default constructor, no attributes set and account_id will be -2
     */
    public User(){
        account_id=-2;
    }

    /**
     * Constructor with an account id set
     * @param _account_id account id
     */
    public User(int _account_id)
    {
        account_id=_account_id;
        username = "username not set";
    }

    /**
     * Constructor with an account id and username set
     * @param _account_id account id
     * @param _username username
     */
    public User(int _account_id, String _username) {
        account_id = _account_id;
        username = _username;
        phone = "";
    }

    /**
     * Constructor with an account id, phone number, and username set
     * @param _account_id account id
     * @param _username username
     * @param _phone phone number
     */
    public User(int _account_id, String _username, String _phone) {
        account_id = _account_id;
        username = _username;
        phone = _phone;
    }

    /**
     * Returns the username of the user
     * @return username
     */
    @Override
    public String toString() {
        return username;
    }

    /**
     * Gets the user's account id
     * @return account id
     */
    public int getAccount_id() {
        return account_id;
    }

    /**
     * Gets the user's username
     * @return username
     */
    public String getUsername() {
        return username;
    }
}
