package com.example.lendit;

import android.graphics.Bitmap;

import java.sql.Date;
/**
 * @author Joseph Nied
 */
public class Transaction {
    private int transaction_id;
    private User lender;
    private User borrower;
    private Item item;
    private Date borrowed_on;
    private Date to_return_on;
    private boolean returned;
    private String description;
    private Bitmap image;
    private String image_name;

    /**
     * Gets the name of the image
     * @return image name string
     */
    public String getImage_name() {
        return image_name;
    }

    /**
     * Sets the name of the image
     * @param image_name image name string
     */
    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    /**
     * Gets the bitmap image
     * @return bitmap image
     */
    public Bitmap getImage() {
        return image;
    }

    /**
     * Sets the image as a bitmap
     * @param image bitmap image
     */
    public void setImage(Bitmap image) {
        this.image = image;
    }

    /**
     * Default constructor
     */
    public Transaction(){
        transaction_id=-1;
        item = new Item();
    }

    /**
     * Constructor that sets transaction id, lender, borrower, item, borrowed on, return on, returned, description, and image
     * @param _transaction_id transaction id int
     * @param _lender User lender
     * @param _borrower User borrower
     * @param _item Item item
     * @param _borrowed_on Date borrowed on
     * @param _to_return_on Date to return on
     * @param _returned true if returned
     * @param _description description string
     * @param _image image name string
     */
    public Transaction(int _transaction_id, User _lender, User _borrower, Item _item, Date _borrowed_on, Date _to_return_on, boolean _returned,  String _description, String _image) {
        transaction_id = _transaction_id;
        lender = _lender;
        borrower = _borrower;
        item = _item;
        borrowed_on = _borrowed_on;
        to_return_on = _to_return_on;
        returned = _returned;
        description = _description;
        image_name = _image;
    }

    /**
     * Gets the item name
     * @return item name string
     */
    public String getItem_name() {
        return item.item_name;
    }

    /**
     * Sets the item name
     * @param item_name item name string
     */
    public void setItem_name(String item_name) {
        this.item.item_name = item_name;
    }

    /**
     * Checks if item is returned
     * @return true if returned
     */
    public boolean isReturned() {
        return returned;
    }

    /**
     * Gets the date borrowed on
     * @return borrowed on Date
     */
    public Date getBorrowed_on() {
        return borrowed_on;
    }

    /**
     * Gets the date to return on
     * @return returned on Date
     */
    public Date getTo_return_on() {
        return to_return_on;
    }

    /**
     * Gets the transaction id
     * @return transaction id int
     */
    public int getTransaction_id() {
        return transaction_id;
    }

    /**
     * Gets the lender id
     * @return lender id int
     */
    public int getLenderID() {
        return lender.account_id;
    }

    /**
     * Sets the User lender
     * @param lender User lender
     */
    public void setLender(User lender) {
        this.lender = lender;
    }

    /**
     * Gets the borrower id
     * @return borrower id int
     */
    public int getBorrowerID() {
        return borrower.account_id;
    }

    /**
     * Sets the borrower
     * @param borrower borrower User
     */
    public void setBorrower(User borrower) {
        this.borrower = borrower;
    }

    /**
     * Gets the item
     * @return Item item
     */
    public Item getItem() {
        return item;
    }

    /**
     * Sets the item
     * @param item Item item
     */
    public void setItem(Item item) {
        this.item = item;
    }

    /**
     * Sets the date borrowed on
     * @param borrowed_on Date borrowed on
     */
    public void setBorrowed_on(Date borrowed_on) {
        this.borrowed_on = borrowed_on;
    }

    /**
     * Sets the date to return on
     * @param to_return_on Date returned on
     */
    public void setTo_return_on(Date to_return_on) {
        this.to_return_on = to_return_on;
    }

    /**
     * Set the item returned
     * @param returned true if returned
     */
    public void setReturned(boolean returned) {
        this.returned = returned;
    }

    /**
     * Gets the description
     * @return description string
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description
     * @param description description string
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns a string with transaction information
     * @return string of name, borrow date, and if returned
     */
    @Override
    public String toString() {
        return "Item: " + getItem_name()
                + "\nBorrowed: " + getBorrowed_on()
                + "\nReturned: " + isReturned();
    }
}
